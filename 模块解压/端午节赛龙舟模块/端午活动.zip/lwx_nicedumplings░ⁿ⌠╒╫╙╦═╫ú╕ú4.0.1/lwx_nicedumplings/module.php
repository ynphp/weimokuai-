<?php

defined('IN_IA') or exit('Access Denied');
class lwx_nicedumplingsModule extends WeModule
{
}
